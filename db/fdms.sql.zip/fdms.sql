-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 05, 2020 at 12:46 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fdms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(3) NOT NULL,
  `a_name` varchar(50) NOT NULL,
  `a_mob` int(10) NOT NULL,
  `a_dob` date NOT NULL,
  PRIMARY KEY  (`a_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--


-- --------------------------------------------------------

--
-- Table structure for table `biomass`
--

CREATE TABLE `biomass` (
  `bio_id` int(50) NOT NULL auto_increment,
  `bio_name` varchar(500) NOT NULL,
  `bio_wood` varchar(500) NOT NULL,
  `bio_drylf` varchar(500) NOT NULL,
  `bio_rawlf` varchar(500) NOT NULL,
  `bio_grass` varchar(500) NOT NULL,
  `bio_sign` varchar(500) NOT NULL,
  PRIMARY KEY  (`bio_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `biomass`
--

INSERT INTO `biomass` (`bio_id`, `bio_name`, `bio_wood`, `bio_drylf`, `bio_rawlf`, `bio_grass`, `bio_sign`) VALUES
(20, 'gaddemane', '12', '15', '20', '121', 'dsh'),
(19, 'gaddemane', '100ton', '15', '20', '6667', 'dileep'),
(18, 'dil', '100ton', '15', '20', '3232', 'ssh'),
(21, 'aaaaaaaaa', '10', '15', '20', '55', 'kjhhvdsjhds'),
(27, 'kkk', '11', '11', '1', '111', 'aaa'),
(26, 'rrrr', '1', '1', '1', '1', 'rr');

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `comp_id` int(8) NOT NULL auto_increment,
  `comp_firno` varchar(20) NOT NULL,
  `comp_date` date NOT NULL,
  `comp_place` varchar(250) NOT NULL,
  `comp_erno` varchar(100) NOT NULL,
  `comp_criminal_name` varchar(500) NOT NULL,
  `comp_item` varchar(250) NOT NULL,
  `comp_item_in_no` varchar(50) NOT NULL,
  `comp_item_in_kg` varchar(40) NOT NULL,
  `comp_item_in_meter` varchar(40) NOT NULL,
  `comp_deposit` varchar(899) NOT NULL,
  `comp_status` varchar(899) NOT NULL,
  PRIMARY KEY  (`comp_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=468 ;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`comp_id`, `comp_firno`, `comp_date`, `comp_place`, `comp_erno`, `comp_criminal_name`, `comp_item`, `comp_item_in_no`, `comp_item_in_kg`, `comp_item_in_meter`, `comp_deposit`, `comp_status`) VALUES
(464, '12111', '2020-09-16', 'hegde', '002252', 'di;eep', 'hhegde', 'kdsgkjsdfkj', 'jfkjgsdjkfkj', 'jfvbndskjdjk', '10,000', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `contractor`
--

CREATE TABLE `contractor` (
  `contractor_id` int(15) NOT NULL auto_increment,
  `contractor_name` varchar(50) NOT NULL,
  `contractor_code` varchar(50) NOT NULL,
  `contractor_adress` varchar(250) NOT NULL,
  `contractor_city` varchar(100) NOT NULL,
  `contractor_email` varchar(100) NOT NULL,
  `contractor_contact` varchar(10) NOT NULL,
  PRIMARY KEY  (`contractor_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `contractor`
--

INSERT INTO `contractor` (`contractor_id`, `contractor_name`, `contractor_code`, `contractor_adress`, `contractor_city`, `contractor_email`, `contractor_contact`) VALUES
(2, 'baju', '4785', 'hegdekatta', 'sirsi', 'dileephegde@gmail.com', '8197987358'),
(3, 'dilli', 'DHDG123', 'sirsai', 'sirsi', 'sss@sss.com', '2323435676');

-- --------------------------------------------------------

--
-- Table structure for table `cutting`
--

CREATE TABLE `cutting` (
  `cutting_id` int(8) NOT NULL auto_increment,
  `tree_id` varchar(8) NOT NULL,
  `total_trees` varchar(50) NOT NULL,
  `cutting_date` date NOT NULL,
  PRIMARY KEY  (`cutting_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=324240 ;

--
-- Dumping data for table `cutting`
--

INSERT INTO `cutting` (`cutting_id`, `tree_id`, `total_trees`, `cutting_date`) VALUES
(324236, '3', '23', '2020-03-13'),
(24, '12', '23', '1999-09-09'),
(324237, '', '', '0000-00-00'),
(324235, '5', '77', '2020-02-13'),
(324238, '5', '44', '2020-03-03'),
(324239, '8', '44', '2020-10-14');

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE `family` (
  `fam_id` int(100) NOT NULL auto_increment,
  `fam_member_code` varchar(100) NOT NULL,
  `fam_village` varchar(500) NOT NULL,
  PRIMARY KEY  (`fam_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`fam_id`, `fam_member_code`, `fam_village`) VALUES
(4, 'vinayak', 'kolhapur');

-- --------------------------------------------------------

--
-- Table structure for table `hydra`
--

CREATE TABLE `hydra` (
  `hydra_id` int(100) NOT NULL auto_increment,
  `hydra_well` varchar(500) NOT NULL,
  `hydra_sector` varchar(500) NOT NULL,
  `hydra_village` varchar(500) NOT NULL,
  `hydra_date` date NOT NULL,
  `hydra_bore` varchar(500) NOT NULL,
  `hydra_level` varchar(500) NOT NULL,
  `hydra_quantity` varchar(500) NOT NULL,
  `hydra_sign` varchar(500) NOT NULL,
  PRIMARY KEY  (`hydra_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hydra`
--

INSERT INTO `hydra` (`hydra_id`, `hydra_well`, `hydra_sector`, `hydra_village`, `hydra_date`, `hydra_bore`, `hydra_level`, `hydra_quantity`, `hydra_sign`) VALUES
(4, 'vinayak', '12', 'kolhapur', '2020-08-31', '150', '3', '5', 'vsl');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `loan_id` int(50) NOT NULL auto_increment,
  `loan_name` varchar(500) NOT NULL,
  `loan_gdate` date NOT NULL,
  `loan_ammount` varchar(500) NOT NULL,
  `loan_month` varchar(500) NOT NULL,
  `loan_rpdate` date NOT NULL,
  `loan_repdate` date NOT NULL,
  `loan_prinamt` varchar(500) NOT NULL,
  `loan_interest` varchar(500) NOT NULL,
  `loan_total` varchar(500) NOT NULL,
  `loan_extra` varchar(500) NOT NULL,
  `loan_sign` varchar(500) NOT NULL,
  PRIMARY KEY  (`loan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `loan_name`, `loan_gdate`, `loan_ammount`, `loan_month`, `loan_rpdate`, `loan_repdate`, `loan_prinamt`, `loan_interest`, `loan_total`, `loan_extra`, `loan_sign`) VALUES
(4, 'Vinayak', '2020-09-03', '250', '2', '2020-09-03', '2020-09-11', '2000', '4', '2080', '2000', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(10) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `utype` varchar(10) NOT NULL,
  `hint_q` varchar(30) NOT NULL,
  `hint_a` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY  (`login_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `username`, `password`, `utype`, `hint_q`, `hint_a`, `status`) VALUES
(1, 'admin@gmail.com', '7889', 'admin', 'your name', 'admin', 'active'),
(2, 'dileep@gmail.com', '123', 'officer', 'who r u', 'officer', 'active'),
(3, 'vinoad@gmail.com', '123123', 'officer', 'Enter Your Email', 'vinoad@gmail.com', 'active'),
(4, 'dileephegdehegdekatt', '123123', 'officer', 'Enter Your Mobile', '8197987358', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `mem_id` int(100) NOT NULL auto_increment,
  `fam_id` int(100) NOT NULL,
  `member_name` varchar(20) NOT NULL,
  `mem_age` varchar(200) NOT NULL,
  `mem_gender` varchar(500) NOT NULL,
  `mem_relation` varchar(500) NOT NULL,
  PRIMARY KEY  (`mem_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`mem_id`, `fam_id`, `member_name`, `mem_age`, `mem_gender`, `mem_relation`) VALUES
(5, 3, '', '33', 'male', 'father'),
(7, 4, 'San', '27', 'Male', 'Broher'),
(8, 4, 'vinoad', '27', 'Male', 'son'),
(9, 4, 'ravi', '25', 'Male', 'Brother'),
(10, 4, '', '', 'Male', '');

-- --------------------------------------------------------

--
-- Table structure for table `officer`
--

CREATE TABLE `officer` (
  `o_id` int(4) NOT NULL auto_increment,
  `o_fullname` varchar(100) NOT NULL,
  `o_designation` varchar(100) NOT NULL,
  `o_dob` date NOT NULL,
  `o_gender` varchar(11) NOT NULL,
  `o_adress` varchar(500) NOT NULL,
  `o_code` varchar(10) NOT NULL,
  `o_contact` varchar(10) NOT NULL,
  `o_email` varchar(100) NOT NULL,
  `o_photo` varchar(500) NOT NULL,
  PRIMARY KEY  (`o_id`),
  UNIQUE KEY `o_code` (`o_code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `officer`
--

INSERT INTO `officer` (`o_id`, `o_fullname`, `o_designation`, `o_dob`, `o_gender`, `o_adress`, `o_code`, `o_contact`, `o_email`, `o_photo`) VALUES
(70, 'dilip', 'gaurd', '2020-12-31', 'male', 'sirs', '12136', '8197987358', 'dddd', 'Screenshot_2017-09-07-21-03-58.png'),
(71, 'vinoad Katagi', 'bcaa', '2020-09-03', 'male', 'dwdw', 'a', '8105953436', 'vinoad@gmail.com', 'bg.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(8) NOT NULL auto_increment,
  `contractor_id` int(8) NOT NULL,
  `tree_id` int(8) NOT NULL,
  `tree_stock` varchar(10) NOT NULL,
  `sale_rate` varchar(12) NOT NULL,
  `sale_date` date NOT NULL,
  PRIMARY KEY  (`sales_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=474 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `contractor_id`, `tree_id`, `tree_stock`, `sale_rate`, `sale_date`) VALUES
(460, 3, 3, 'wwww', '5555', '2020-03-11'),
(461, 2, 1, 'segdrfd', '22', '2020-03-18'),
(467, 3, 3, '23', '55', '2020-03-19'),
(462, 2, 3, 'segdrfd', '32', '2020-03-19'),
(464, 2, 3, '33334', '2344', '2020-12-31'),
(465, 2, 3, '23', '2344', '2020-12-31'),
(466, 2, 3, 'segdrfd', '565', '2020-03-19'),
(468, 2, 3, 'segdrfd', '23', '2020-03-20'),
(469, 2, 5, 'segdrfd', '234', '2020-03-19'),
(470, 2, 5, '33334', '454', '2020-03-11'),
(471, 3, 1, '23', '2213', '2020-03-11'),
(472, 3, 5, '12', '1500', '2020-09-03'),
(473, 2, 1, '2', '500', '2020-09-15');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stock_id` int(8) NOT NULL auto_increment,
  `tree_id` varchar(8) NOT NULL,
  `tree_stock` varchar(10) NOT NULL,
  PRIMARY KEY  (`stock_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock_id`, `tree_id`, `tree_stock`) VALUES
(30, '3', '33334'),
(31, '3', '3233'),
(28, '3', '23'),
(23, '6357', 'wwww');

-- --------------------------------------------------------

--
-- Table structure for table `stove`
--

CREATE TABLE `stove` (
  `stove_id` int(50) NOT NULL auto_increment,
  `stove_name` varchar(500) NOT NULL,
  `stove_type` varchar(500) NOT NULL,
  `stove_date` date NOT NULL,
  `stove_sign` varchar(500) NOT NULL,
  PRIMARY KEY  (`stove_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `stove`
--

INSERT INTO `stove` (`stove_id`, `stove_name`, `stove_type`, `stove_date`, `stove_sign`) VALUES
(2, 'dileep', 'astra', '2020-02-13', 'dsga'),
(4, 'dileep', 'astra', '2020-03-11', 'dsga');

-- --------------------------------------------------------

--
-- Table structure for table `trees`
--

CREATE TABLE `trees` (
  `tree_id` int(8) NOT NULL auto_increment,
  `tree_name` varchar(50) NOT NULL,
  `tree_discription` varchar(250) NOT NULL,
  `tree_photo` varchar(500) NOT NULL,
  PRIMARY KEY  (`tree_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `trees`
--


-- --------------------------------------------------------

--
-- Table structure for table `visit`
--

CREATE TABLE `visit` (
  `visit_id` int(100) NOT NULL auto_increment,
  `visit_name` varchar(500) NOT NULL,
  `visit_date` date NOT NULL,
  `visit_discription` varchar(500) NOT NULL,
  `visit_sign` varchar(100) NOT NULL,
  PRIMARY KEY  (`visit_id`),
  KEY `visit_date` (`visit_date`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `visit`
--


-- --------------------------------------------------------

--
-- Table structure for table `wildlife`
--

CREATE TABLE `wildlife` (
  `animal_id` int(8) NOT NULL auto_increment,
  `animal_name` varchar(50) NOT NULL,
  `animal_code` varchar(10) NOT NULL,
  `animal_age` varchar(20) NOT NULL,
  `animal_information` varchar(500) NOT NULL,
  `animal_image` varchar(500) NOT NULL,
  PRIMARY KEY  (`animal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `wildlife`
--

INSERT INTO `wildlife` (`animal_id`, `animal_name`, `animal_code`, `animal_age`, `animal_information`, `animal_image`) VALUES
(4, 'bg', 'raghu', '22', 'lll', ''),
(2, 'mani', 'jj', 'jj', 'jj', 'Screenshot_2017-09-07-21-03-58.png'),
(7, 'manga', '', '', '', ''),
(5, 'tiger', 'fdffdfd', '22', 'WILD ANIMAL', ''),
(6, 'dileep', 'fdffdfd', '22', 'WILD ANIMAL', '');
