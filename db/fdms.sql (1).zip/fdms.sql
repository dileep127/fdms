-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 12, 2020 at 02:27 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fdms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `a_id` int(3) NOT NULL,
  `a_name` varchar(50) NOT NULL,
  `a_mob` int(10) NOT NULL,
  `a_dob` date NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--


-- --------------------------------------------------------

--
-- Table structure for table `biomass`
--

CREATE TABLE IF NOT EXISTS `biomass` (
  `bio_id` int(50) NOT NULL AUTO_INCREMENT,
  `bio_name` varchar(500) NOT NULL,
  `bio_wood` varchar(500) NOT NULL,
  `bio_drylf` varchar(500) NOT NULL,
  `bio_rawlf` varchar(500) NOT NULL,
  `bio_grass` varchar(500) NOT NULL,
  `bio_sign` varchar(500) NOT NULL,
  PRIMARY KEY (`bio_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `biomass`
--

INSERT INTO `biomass` (`bio_id`, `bio_name`, `bio_wood`, `bio_drylf`, `bio_rawlf`, `bio_grass`, `bio_sign`) VALUES
(1, 'dileep', '100ton', '15', '20', '25', 'dileep'),
(4, 'hegde', '12', '11', '12', '55', 'dsh'),
(5, 'dileep', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE IF NOT EXISTS `complaint` (
  `comp_id` int(8) NOT NULL AUTO_INCREMENT,
  `comp_firno` varchar(20) NOT NULL,
  `comp_date` date NOT NULL,
  `comp_place` varchar(250) NOT NULL,
  `comp_erno` varchar(100) NOT NULL,
  `comp_criminal_name` varchar(500) NOT NULL,
  `comp_item` varchar(250) NOT NULL,
  `comp_item_in_no` varchar(50) NOT NULL,
  `comp_item_in_kg` varchar(40) NOT NULL,
  `comp_item_in_meter` varchar(40) NOT NULL,
  `comp_deposit` varchar(899) NOT NULL,
  `comp_status` varchar(899) NOT NULL,
  PRIMARY KEY (`comp_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=461 ;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`comp_id`, `comp_firno`, `comp_date`, `comp_place`, `comp_erno`, `comp_criminal_name`, `comp_item`, `comp_item_in_no`, `comp_item_in_kg`, `comp_item_in_meter`, `comp_deposit`, `comp_status`) VALUES
(458, 'qwq12', '2020-02-14', 'hegde', 'katta', 'di;eep', 'hhegde', 'kdsgkjsdfkj', 'jfkjgsdjkfkj', 'jfvbndskjdjk', 'ndfjdsfjk', 'jnbfdksfs'),
(35, '12g54', '1989-10-10', 'sirsi', 'comp_erno', 'dileep', 'tree', '4', '4', '4', 'kalla', 'sikda'),
(459, '1211', '2020-11-30', 'hegdekata', '23211', 'dileep', 'tree', '55', '50', '55', '150', 'got him'),
(460, '1211', '2020-03-12', 'hegdekatta', '12111', '', 'mara', '55', '500', '100', '10,000', 'he was caught');

-- --------------------------------------------------------

--
-- Table structure for table `contractor`
--

CREATE TABLE IF NOT EXISTS `contractor` (
  `contractor_id` int(15) NOT NULL AUTO_INCREMENT,
  `contractor_name` varchar(50) NOT NULL,
  `contractor_code` varchar(50) NOT NULL,
  `contractor_adress` varchar(250) NOT NULL,
  `contractor_city` varchar(100) NOT NULL,
  `contractor_email` varchar(100) NOT NULL,
  `contractor_contact` varchar(10) NOT NULL,
  PRIMARY KEY (`contractor_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `contractor`
--

INSERT INTO `contractor` (`contractor_id`, `contractor_name`, `contractor_code`, `contractor_adress`, `contractor_city`, `contractor_email`, `contractor_contact`) VALUES
(4, '', '', 'hegdekatta', 'sirsi', 'dileep1999@gmail.com', ''),
(2, 'dileep', 'DHDG123', 'hegdekatta', 'sirsi', 'dileephegde@gmail.com', '8197987358'),
(3, 'dilli', 'DHDG123', 'sirsai', 'sirsi', 'sss@sss.com', '2323435676');

-- --------------------------------------------------------

--
-- Table structure for table `cutting`
--

CREATE TABLE IF NOT EXISTS `cutting` (
  `cutting_id` int(8) NOT NULL AUTO_INCREMENT,
  `tree_id` varchar(8) NOT NULL,
  `total_trees` varchar(50) NOT NULL,
  `cutting_date` date NOT NULL,
  PRIMARY KEY (`cutting_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=324239 ;

--
-- Dumping data for table `cutting`
--

INSERT INTO `cutting` (`cutting_id`, `tree_id`, `total_trees`, `cutting_date`) VALUES
(324236, '3', '23', '2020-03-13'),
(24, '12', '23', '1999-09-09'),
(324237, '', '', '0000-00-00'),
(324235, '3', '23', '2020-02-13'),
(324238, '5', '44', '2020-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE IF NOT EXISTS `family` (
  `fam_id` int(100) NOT NULL AUTO_INCREMENT,
  `fam_member_code` varchar(100) NOT NULL,
  `fam_village` varchar(500) NOT NULL,
  PRIMARY KEY (`fam_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`fam_id`, `fam_member_code`, `fam_village`) VALUES
(1, 'MANOJ', 'hegdekatta'),
(3, 'dileep', 'jaddigadde');

-- --------------------------------------------------------

--
-- Table structure for table `hydra`
--

CREATE TABLE IF NOT EXISTS `hydra` (
  `hydra_id` int(100) NOT NULL AUTO_INCREMENT,
  `hydra_well` varchar(500) NOT NULL,
  `hydra_sector` varchar(500) NOT NULL,
  `hydra_village` varchar(500) NOT NULL,
  `hydra_date` date NOT NULL,
  `hydra_bore` varchar(500) NOT NULL,
  `hydra_level` varchar(500) NOT NULL,
  `hydra_quantity` varchar(500) NOT NULL,
  `hydra_sign` varchar(500) NOT NULL,
  PRIMARY KEY (`hydra_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hydra`
--

INSERT INTO `hydra` (`hydra_id`, `hydra_well`, `hydra_sector`, `hydra_village`, `hydra_date`, `hydra_bore`, `hydra_level`, `hydra_quantity`, `hydra_sign`) VALUES
(1, 'hegdekatta', 'srs', 'aaaabbb', '2020-02-07', 'aaabbb', 'nfdhgdfg', 'aaabbb', 'aaa bbbb'),
(3, 'hegdekatta', 'qqqqqqqqqqqqqqqqqqqqqqqq', 'ONI', '2020-03-21', 'aaabbb', 'aaa', 'bfd', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
  `loan_id` int(50) NOT NULL AUTO_INCREMENT,
  `loan_name` varchar(500) NOT NULL,
  `loan_gdate` date NOT NULL,
  `loan_ammount` varchar(500) NOT NULL,
  `loan_month` varchar(500) NOT NULL,
  `loan_rpdate` date NOT NULL,
  `loan_repdate` date NOT NULL,
  `loan_prinamt` varchar(500) NOT NULL,
  `loan_interest` varchar(500) NOT NULL,
  `loan_total` varchar(500) NOT NULL,
  `loan_extra` varchar(500) NOT NULL,
  `loan_sign` varchar(500) NOT NULL,
  PRIMARY KEY (`loan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `loan_name`, `loan_gdate`, `loan_ammount`, `loan_month`, `loan_rpdate`, `loan_repdate`, `loan_prinamt`, `loan_interest`, `loan_total`, `loan_extra`, `loan_sign`) VALUES
(2, 'dg', '2020-02-04', '', 'dg', '2020-02-10', '2020-02-13', 'dg', 'dg', 'dg', 'dg', 'dg ');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `login_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `utype` varchar(10) NOT NULL,
  `hint_q` varchar(30) NOT NULL,
  `hint_a` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `username`, `password`, `utype`, `hint_q`, `hint_a`, `status`) VALUES
(1, 'admin@gmail.com', '12345678', 'admin', 'your name', 'admin', 'active'),
(2, 'dileep@gmail.com', '123', 'officer', 'who r u', 'officer', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `mem_id` int(100) NOT NULL AUTO_INCREMENT,
  `fam_id` int(100) NOT NULL,
  `mem_age` varchar(200) NOT NULL,
  `mem_gender` varchar(500) NOT NULL,
  `mem_relation` varchar(500) NOT NULL,
  PRIMARY KEY (`mem_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`mem_id`, `fam_id`, `mem_age`, `mem_gender`, `mem_relation`) VALUES
(1, 1, '222', 'male', 'bro'),
(5, 3, '33', 'male', 'father');

-- --------------------------------------------------------

--
-- Table structure for table `officer`
--

CREATE TABLE IF NOT EXISTS `officer` (
  `o_id` int(4) NOT NULL AUTO_INCREMENT,
  `o_fullname` varchar(100) NOT NULL,
  `o_designation` varchar(100) NOT NULL,
  `o_dob` date NOT NULL,
  `o_gender` varchar(11) NOT NULL,
  `o_adress` varchar(500) NOT NULL,
  `o_code` varchar(10) NOT NULL,
  `o_contact` varchar(10) NOT NULL,
  `o_email` varchar(100) NOT NULL,
  `o_photo` varchar(500) NOT NULL,
  PRIMARY KEY (`o_id`),
  UNIQUE KEY `o_code` (`o_code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `officer`
--

INSERT INTO `officer` (`o_id`, `o_fullname`, `o_designation`, `o_dob`, `o_gender`, `o_adress`, `o_code`, `o_contact`, `o_email`, `o_photo`) VALUES
(59, 'dileep', 'hod', '1999-03-03', 'male', 'hegdekatta', '777778', '8197987358', 'dileep1999@gmail.com', 'IMG-20190831-WA0024-03.jpeg'),
(70, 'dilip', 'gaurd', '2020-12-31', 'male', 'sirs', '12136', '8197987358', 'dddd', 'Screenshot_2017-09-07-21-03-58.png');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `sales_id` int(8) NOT NULL AUTO_INCREMENT,
  `contractor_id` int(8) NOT NULL,
  `tree_id` int(8) NOT NULL,
  `tree_stock` varchar(10) NOT NULL,
  `sale_rate` varchar(12) NOT NULL,
  `sale_date` date NOT NULL,
  PRIMARY KEY (`sales_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=472 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `contractor_id`, `tree_id`, `tree_stock`, `sale_rate`, `sale_date`) VALUES
(460, 3, 3, 'wwww', '5555', '2020-03-11'),
(461, 2, 1, 'segdrfd', '22', '2020-03-18'),
(467, 3, 3, '23', '55', '2020-03-19'),
(462, 2, 3, 'segdrfd', '32', '2020-03-19'),
(464, 2, 3, '33334', '2344', '2020-12-31'),
(465, 2, 3, '23', '2344', '2020-12-31'),
(466, 2, 3, 'segdrfd', '565', '2020-03-19'),
(468, 2, 3, 'segdrfd', '23', '2020-03-20'),
(469, 2, 5, 'segdrfd', '234', '2020-03-19'),
(470, 2, 5, '33334', '454', '2020-03-11'),
(471, 3, 1, '23', '2213', '2020-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `stock_id` int(8) NOT NULL AUTO_INCREMENT,
  `tree_id` varchar(8) NOT NULL,
  `tree_stock` varchar(10) NOT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock_id`, `tree_id`, `tree_stock`) VALUES
(30, '3', '33334'),
(31, '3', '3233'),
(28, '3', '23'),
(23, '6357', 'wwww');

-- --------------------------------------------------------

--
-- Table structure for table `stove`
--

CREATE TABLE IF NOT EXISTS `stove` (
  `stove_id` int(50) NOT NULL AUTO_INCREMENT,
  `stove_name` varchar(500) NOT NULL,
  `stove_type` varchar(500) NOT NULL,
  `stove_date` date NOT NULL,
  `stove_sign` varchar(500) NOT NULL,
  PRIMARY KEY (`stove_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `stove`
--

INSERT INTO `stove` (`stove_id`, `stove_name`, `stove_type`, `stove_date`, `stove_sign`) VALUES
(2, 'dileep', 'astra', '2020-02-13', 'dsga'),
(4, 'dileep', 'astra', '2020-03-11', 'dsga');

-- --------------------------------------------------------

--
-- Table structure for table `trees`
--

CREATE TABLE IF NOT EXISTS `trees` (
  `tree_id` int(8) NOT NULL AUTO_INCREMENT,
  `tree_name` varchar(50) NOT NULL,
  `tree_discription` varchar(250) NOT NULL,
  `tree_photo` varchar(500) NOT NULL,
  PRIMARY KEY (`tree_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `trees`
--

INSERT INTO `trees` (`tree_id`, `tree_name`, `tree_discription`, `tree_photo`) VALUES
(1, 'rrr', 'rtrf', ''),
(3, 'ghhhhhhhhhhh', 'ghfshf', ''),
(6, 'matti', 'nothing', ''),
(5, 'aksa', 'fghfghgf', 'IMG-20190831-WA0024-03.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `visit`
--

CREATE TABLE IF NOT EXISTS `visit` (
  `visit_id` int(100) NOT NULL AUTO_INCREMENT,
  `visit_name` varchar(500) NOT NULL,
  `visit_date` date NOT NULL,
  `visit_discription` varchar(500) NOT NULL,
  `visit_sign` varchar(100) NOT NULL,
  PRIMARY KEY (`visit_id`),
  KEY `visit_date` (`visit_date`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `visit`
--

INSERT INTO `visit` (`visit_id`, `visit_name`, `visit_date`, `visit_discription`, `visit_sign`) VALUES
(1, 'DILEEEPA', '2020-03-06', 'abcd', 'abcd'),
(6, '', '2020-03-04', 'XVX', 'SDF'),
(3, 'zxcxz', '2020-03-11', 'kk', 'kk'),
(4, 'xcx', '2020-03-11', 'dfds', 'sfs'),
(5, 'xcxz', '2020-03-12', 'zxz', 'SDFD'),
(7, 'dileep', '2020-03-20', 'dfds', 'dilllep');

-- --------------------------------------------------------

--
-- Table structure for table `wildlife`
--

CREATE TABLE IF NOT EXISTS `wildlife` (
  `animal_id` int(8) NOT NULL AUTO_INCREMENT,
  `animal_name` varchar(50) NOT NULL,
  `animal_code` varchar(10) NOT NULL,
  `animal_age` varchar(20) NOT NULL,
  `animal_information` varchar(500) NOT NULL,
  `animal_image` varchar(500) NOT NULL,
  PRIMARY KEY (`animal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `wildlife`
--

INSERT INTO `wildlife` (`animal_id`, `animal_name`, `animal_code`, `animal_age`, `animal_information`, `animal_image`) VALUES
(4, 'tg', 'yfffffffd', '22', 'lll', 'Screenshot_2017-09-08-22-36-15.png'),
(2, 'mani', 'jj', 'jj', 'jj', 'Screenshot_2017-09-07-21-03-58.png'),
(3, 'gayyyy', 'yfffffffd', '45', 'fddddddddd', 'Screenshot_2017-09-08-22-36-28.png'),
(5, 'tiger', 'fdffdfd', '22', 'WILD ANIMAL', 'Screenshot_2017-09-06-22-30-38.png'),
(6, 'tiger', 'fdffdfd', '22', 'WILD ANIMAL', 'Screenshot_2017-09-06-22-30-38.png');
